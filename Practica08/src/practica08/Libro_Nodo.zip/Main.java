package practica08;

import Interfaces.FormLogin;

/**
 *
 * @author kevin Isaac Huerta Montero 3322310411 3P
 */
public class Main 
{
    public static void main(String[] args) 
    {
        FormLogin login = new FormLogin();
        login.setVisible(true);
    }
    
}
